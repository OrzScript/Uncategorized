﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using VanityAPI;

namespace abbysal
{
    // Token: 0x02000002 RID: 2
    public partial class Form1 : Form
    {
        // Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
        public Form1()
        {
            this.InitializeComponent();
            this.Load += Form1_Load;
            SettingsTab.Visible = false;
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            await loader();
        }


        private async Task loader()
        {
            await Task.Delay(1000);
            label4.Text = "Loading.";
            await Task.Delay(1000);
            label4.Text = "Loading..";
            await Task.Delay(1000);
            label4.Text = "Loading...";
            await Task.Delay(100);
            label4.Text = "Loading.";
            await Task.Delay(100);
            label4.Text = "Loading..";
            await Task.Delay(1000);
            label4.Text = "Loaded!";
            Loading.Visible = false;
        }

        // Token: 0x06000002 RID: 2 RVA: 0x00002068 File Offset: 0x00000268
        private void button1_Click(object sender, EventArgs e)
        {
            Api.Inject();
        }

        // Token: 0x06000003 RID: 3 RVA: 0x00002071 File Offset: 0x00000271
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
        }

        // Token: 0x06000004 RID: 4 RVA: 0x00002074 File Offset: 0x00000274
        private void button2_Click(object sender, EventArgs e)
        {
            Api.Execute(this.richTextBox1.Text);
        }

        // Token: 0x06000005 RID: 5 RVA: 0x00002088 File Offset: 0x00000288
        private void button3_Click(object sender, EventArgs e)
        {
            Api.KillRoblox(); // who uses APi to kill boblox
        }

        // Token: 0x06000006 RID: 6 RVA: 0x00002091 File Offset: 0x00000291

        // Token: 0x06000007 RID: 7 RVA: 0x00002094 File Offset: 0x00000294
        private void button4_Click(object sender, EventArgs e)
        {
            this.richTextBox1.Text = "";
        }

        // Token: 0x06000008 RID: 8 RVA: 0x000020A8 File Offset: 0x000002A8
        private void button5_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Txt and Lua Files|*.txt;*.lua";
            bool flag = openFileDialog.ShowDialog() == DialogResult.OK;
            if (flag)
            {
                this.richTextBox1.Text = File.ReadAllText(openFileDialog.FileName);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e) // open script
        {
            base.Hide();
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Text Files (*.txt)|*.txt|Lua Files (*.lua)|*.lua";
                openFileDialog.Title = "Open File";
                bool flag = openFileDialog.ShowDialog() == DialogResult.OK;
                if (flag)
                {
                    try
                    {
                        string text = File.ReadAllText(openFileDialog.FileName);
                        richTextBox1.Text = text;

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error loading file: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            base.Show();
        }

        private void label6_Click(object sender, EventArgs e) // doesnt depend on API anymore
        {
            MessageBox.Show("Process terminated.", "Wheat Executor", MessageBoxButtons.OK, MessageBoxIcon.None);
            Process[] processesByName = Process.GetProcessesByName("RobloxPlayerBeta");
            foreach (Process process in processesByName)
            {
                process.Kill();
                process.WaitForExit();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            SettingsTab.Visible = false;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            SettingsTab.Visible = true;
        }

        private void guna2ToggleSwitch1_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Process terminated.", "Wheat Executor", MessageBoxButtons.OK, MessageBoxIcon.None);
            Process[] processesByName = Process.GetProcessesByName("RobloxPlayerBeta");
            foreach (Process process in processesByName)
            {
                process.Kill();
                process.WaitForExit();
            }
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            Api.Inject();
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            base.Hide();
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Text Files (*.txt)|*.txt|Lua Files (*.lua)|*.lua";
                openFileDialog.Title = "Open File";
                bool flag = openFileDialog.ShowDialog() == DialogResult.OK;
                if (flag)
                {
                    try
                    {
                        string text = File.ReadAllText(openFileDialog.FileName);
                        richTextBox1.Text = text;

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error loading file: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            base.Show();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Api.Execute(richTextBox1.Text);
        }

        private void label6_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized; // i struggled on this one brah :sob:
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            SettingsTab.Visible = true;
        }
    }
}

// orzscript ( me ) did everything fr